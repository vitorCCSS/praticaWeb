function validaProc()
{
    for(let i = 10; i > 0; i--)
    {
        console.log("passou a "+i+"º vez e o numero é o: "+i);
    }
    return false;



}